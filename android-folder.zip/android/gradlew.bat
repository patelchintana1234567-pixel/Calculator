@echo off
 echo placeholder